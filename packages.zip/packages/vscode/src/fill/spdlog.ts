import { Module } from "@coder/protocol";
import { client } from "@coder/ide/src/fill/client";

export = client.modules[Module.Spdlog];
