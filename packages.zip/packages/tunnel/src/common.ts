export enum TunnelCloseCode {
	Normal = 1000,
	Error = 4000,
	ConnectionRefused = 4001,
}
