export * from "../../../../node_modules/util";
import { implementation } from "../../../../node_modules/util.promisify";

export const promisify = implementation;
