import { Module } from "@coder/protocol";
import { client } from "./client";

export = client.modules[Module.Fs];
